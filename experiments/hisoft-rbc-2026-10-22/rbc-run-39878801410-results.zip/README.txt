RBC five-shard compiler and native ZX-UX runner results

This is the unmodified per-program build report, compiled SSX1 output and
screen frames from public GitHub Actions run 39878801410, main revision
5a5e0ee2ec1b77c4fa49fa3f0361e7718d87d6d9. The original run's temporary
archived inputs and third-party compiler sources are not included here: the
original 60 programs, 48K ROM, and the exact external fork are identified in
the permanent HANDOVER-RBC-2026-10-22.md.

The workflow collected failures on purpose. A passing runner job does not
mean every BASIC program compiled. Nor does a successful compile establish
faithful graphics or controls. Each shard results file has the raw compiler
output and boolean result of its 24 or 25 inputs. SHA256SUMS.txt checks all
persisted member bytes; every file remains on permanent GitHub.
