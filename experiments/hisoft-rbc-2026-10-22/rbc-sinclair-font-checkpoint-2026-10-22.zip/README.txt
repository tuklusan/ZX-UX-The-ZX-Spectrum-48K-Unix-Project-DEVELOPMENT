RBC CHECKPOINT -- SOURCE, TESTS AND REPRODUCIBLE BUILD OUTPUTS

Source of truth is the public development repository:
  https://github.com/tuklusan/ZX-UX-The-ZX-Spectrum-48K-Unix-Project-DEVELOPMENT
Original Sinclair BASIC sources remain in src/bonus/60-programs and must not be edited.
This ZIP holds the current runnable rbc source and the latest generated game outputs.

External HiSoft compiler fork, exact commit:
  https://github.com/tuklusan/Python-BASIC-Compiler-for-ZX-Spectrum-Hisoft
  7cc87dafb58fcf5632b7190320dd11c30b4fe961
The separately fetched compiler keeps its original license in that checkout.

Preferred 8x8 font source, exact commit:
  https://github.com/tuklusan/font8x8
  8e279d2d864e79128e96188a6b9526cfa3fbfef9
This file contains the converted 768-byte printable VGA font. Reverse row bit
order when regenerating font32.bin from font8x8_basic.h. Keep UDG storage separate.

rbc/rbc.py depends on the two compiler modules in this ZIP and Python modules
in src/zx-ux-sdk from the public development repository. The ROM is at
src/zx-ux-sdk/rom/48.rom. Obtain the original HiSoft BASIC v1.1 48K tape.

Example:
  python rbc/rbc.py PROGRAM.bas --frontend /path/to/compiler-fork \
    --sdk /path/to/src/zx-ux-sdk --rom /path/to/src/zx-ux-sdk/rom/48.rom \
    --tape /path/to/HiSoft-v1.1.tap -o PROGRAM.ssx --report PROGRAM.json

The next-line jump correction changes only tokenized in-memory compiler input.
The original BASIC tape files are not rewritten. Invaders line 50 calling
GO SUB 70 executes at line 100 because 70 is absent. This is valid BASIC.

Test result summary from this checkout: 9 focused Python tests pass.
Galaxians and Invaders each compile from text and tape. Both run in the real
ZX-UX kernel model for 260 frames with key input, without an exit or crash.
Galaxians displays an instruction page. Invaders remains visibly corrupted.
A compile is not a complete port; gameplay and visual matching remain open.
Results report the exact values, and SHA256SUMS.txt lists all file hashes.

Original 60-file corpus: 59 tapes parsed by current generic reader; 1 tape
was not decoded. 19 of the 59 readable tapes contain absent literal jump
line numbers, many of which are valid in Sinclair BASIC. Scan report in ZIP.
The full 121-input sweep is not a successful-compile count. See the preserved
checkpoint report and newly collected sweep segments for accurate results.
