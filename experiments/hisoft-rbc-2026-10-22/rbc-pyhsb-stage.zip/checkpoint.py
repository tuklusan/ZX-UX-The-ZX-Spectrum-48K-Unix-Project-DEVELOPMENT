#!/usr/bin/env python3
"""Pack only owned RBC trial source, test results and generated code."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json
root=Path(__file__).resolve().parent
out=Path('/mnt/data/ZX-UX-rbc-pyhsb-stage-2026-10-22.zip')
keep=['rbc/rbc.py','rbc/font32.bin','test_rbc.py','corpus_audit.py',
      'STATUS.txt','checkpoint.py']
keep += [p.relative_to(root).as_posix() for p in sorted((root/'test-out').glob('*')) if p.is_file()]
ins=root.parent
inputs={
  'reference/galaxians-hisoft-first.bin':ins/'out/hisoft-galaxians-57113.bin',
  'reference/galaxians-hisoft-second.bin':ins/'next/galaxians-second.bin',
  'reference/invaders-hisoft-first.bin':ins/'out/hisoft-invaders-54486.bin',
  'reference/invaders-hisoft-second.bin':ins/'next/invaders-second.bin',
  'reference/hello-hisoft-first.bin':ins/'out/hisoft-mini-65324.bin',
}
with ZipFile(out,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
    for p in keep:
        z.write(root/p,p)
    for key,p in inputs.items():z.write(p,key)
print('WROTE',out,out.stat().st_size,'files',len(keep)+len(inputs))
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
