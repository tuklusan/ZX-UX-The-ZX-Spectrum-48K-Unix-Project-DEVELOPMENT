import os,sys,time,subprocess
from pathlib import Path
from Xlib import display,X
import pyautogui as pg
r=Path('/mnt/data/hisoft-ssx-lab');o=r/'next';os.chdir(r)
name=sys.argv[1] if len(sys.argv)>1 else 'galaxians'
env={**os.environ,'DISPLAY':':95','HOME':str(r/'home'),'LD_LIBRARY_PATH':str(r/'fuse-root/usr/lib/x86_64-linux-gnu'),'SDL_AUDIODRIVER':'dummy'}
pr=subprocess.Popen([str(r/'work/fuse-sdl-patched'),'--machine','48','--no-sound','--speed','100','--snapshot',str(r/'out'/f'hisoft-{name}.sna')],env=env,stdout=(o/'fuse.log').open('wb'),stderr=subprocess.STDOUT)
print('pid',pr.pid,flush=True)
time.sleep(1)
d=display.Display();w=d.screen().root.query_tree().children
if w: d.set_input_focus(w[-1],X.RevertToParent,X.CurrentTime);d.sync()
def k(ch):pg.keyDown(ch);time.sleep(.045);pg.keyUp(ch);time.sleep(.11)
def combo(*keys):
 for key in keys:pg.keyDown(key)
 time.sleep(.1)
 for key in keys[::-1]:pg.keyUp(key)
 time.sleep(.2)
def shot(tag): pg.screenshot().save(str(o/f'{name}-{tag}.png'))
shot('start')
# HiSoft *X
combo('ctrl','b');k('x');time.sleep(.6);shot('afterx')
# Sinclair 48K CLEAR is X in keyword (K) mode
k('x');time.sleep(.3);shot('afterclear')
for ch in ' 64000':k(ch)
shot('cleartyped');k('enter');time.sleep(.6);shot('cleared')
combo('ctrl','b');k('c');time.sleep(1)
shot('compiled0')
for i in range(5):k('space');time.sleep(.75);shot('compiled'+str(i+1))
print('done',pr.pid,flush=True)
