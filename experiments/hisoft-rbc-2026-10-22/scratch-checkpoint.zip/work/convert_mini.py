#!/usr/bin/env python3
"""Disposable 44-byte HiSoft v1.1 to ZX-UX SSX1 proof-of-concept.

Only relocates established internal references. Not a general HiSoft converter.
"""
import sys,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'sdk'))
import rld
out=Path('/mnt/data/hisoft-ssx-lab/out')
raw=(out/'hisoft-mini-65324.bin').read_bytes()
assert len(raw)==44
assert raw.hex() == 'cd53ff2158ff226c5ccd47ff050048454c4c4f3e0dd7215827d9c9e14e234623545d09e5c33c203e02c30116'
# Real HiSoft entry and ROM call instructions remain; a wrapper allows native _exit.
wrapper=bytes.fromhex('cd0c002100003e01cd036076')
assert len(wrapper)==12
image=bytearray(wrapper+raw)
fixups=[(1,12),(13,12+39),(16,12+44),(22,12+27)]
for at,target in fixups:
 image[at:at+2]=struct.pack('<H',target)
rs=rld.reloc_stream([a for a,_ in fixups])
hdr=b'SSX1'+struct.pack('<BBHHHHHH',0,20,len(image),0,384,0,0,len(fixups))
result=hdr+struct.pack('<H',rld.fletcher16(hdr+image+rs))+image+rs
parsed=rld.parse_ssx(result)
assert parsed['image']==bytes(image) and parsed['relocs']==[1,13,16,22]
(out/'hisoft-mini-experimental.ssx').write_bytes(result)
print('HiSoft original:',len(raw),'bytes; wrapper',len(wrapper),'bytes; SSX',len(result),'bytes; relocs',parsed['relocs'])
print('ROM instructions unchanged: CALL 203Ch, RST 10h, JP 1601h')
