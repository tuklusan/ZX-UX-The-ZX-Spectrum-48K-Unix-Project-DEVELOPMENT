from pathlib import Path
import zipfile
root=Path('/mnt/data/hisoft-ssx-lab')
z=zipfile.ZipFile('/mnt/data/ZX-UX-GITHUB-REPO-beta-0.2.0.zip')
from make_tapes import tzx_data_blocks, block, header, reduce_xor, mkline
compiler=Path('/mnt/data/HiSoft_BASIC_v1.1_48K_compiler_only.tzx').read_bytes()
for game in ('25-galaxians','58-invaders'):
 name=game.split('-')[1]
 tape=z.read('ZX-UX-GITHUB-REPO/src/bonus/60-programs/'+game+'/BASIC/'+game+'.tzx')
 blocks=list(tzx_data_blocks(tape))
 print(game,[(len(d),d[:20].hex(' ')) for t,d in blocks])
 assert len(blocks)==2
 hd=blocks[0][1]; body=blocks[1][1]
 assert hd[0]==0 and hd[1]==0 and body[0]==255
 assert reduce_xor(hd)==0 and reduce_xor(body)==0
 old=body[1:-1]
 assert int.from_bytes(old[:2],'big')==10
 directive=mkline(1,bytes([0xea,0x3a,0xd3]))
 if name=='invaders':
  # Spectrum BASIC GOSUB 70 falls through to first existing line >=70 (100);
  # HiSoft needs an explicit line 70 for a literal GOSUB 70.
  import struct
  pos=0
  while pos<len(old):
   lineno=int.from_bytes(old[pos:pos+2],'big')
   linelen=int.from_bytes(old[pos+2:pos+4],'little')
   if lineno>=100:break
   pos+=4+linelen
  old=old[:pos]+mkline(70,bytes([0xea])+b' missing target anchor')+old[pos:]
 new=directive+old
 length=len(new)
 h=header(0,name.upper(),length,32768,length)
 d=b'\xff'+new;d+=bytes([reduce_xor(d)])
 out=compiler+block(h)+block(d)
 (root/'inputs'/f'compiler-{name}.tzx').write_bytes(out)
 (root/'inputs'/f'{name}-with-directive.tzx').write_bytes(b'ZXTape!\x1a\x01\x14'+block(h)+block(d))
 print(game,'BASIC old',len(old),'test-source',len(new),'tape',len(out))
