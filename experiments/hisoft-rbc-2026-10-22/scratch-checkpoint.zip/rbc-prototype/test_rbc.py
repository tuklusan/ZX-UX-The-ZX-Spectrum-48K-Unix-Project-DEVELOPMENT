#!/usr/bin/env python3
"""Scratch regression: actual frozen ZX-UX kernel, SSX1 relocation and font effect."""
from __future__ import annotations
import sys
from pathlib import Path
from PIL import Image, ImageChops
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'work' / 'dist_sdk'))
import rvm, rld
CHARS=0x5C36


def run(name):
    ssx = HERE / (name+'.ssx')
    parsed = rld.parse_ssx(ssx.read_bytes())
    assert len(parsed['relocs']) == 7, name
    runner = rvm.run_kernel(ssx, system=ROOT/'inputs'/'ZX-UX.tzx', frames=800)
    assert runner.why == 'exit' and runner.fg.status == 0, (name, runner.why, runner.fg.status)
    mem = runner.session.m.mem
    chars = mem[CHARS] + (mem[CHARS+1] << 8)
    assert chars == 0x3c00, (name, 'CHARS not restored:', hex(chars))
    return runner


if __name__ == '__main__':
    a,b=(Image.open(HERE/n).convert('RGB') for n in ('rbc-mini.png','rbc-font-test.png'))
    diff=ImageChops.difference(a,b)
    assert diff.getbbox() == (32,32,542,414), diff.getbbox()
    top=ImageChops.difference(a.crop((0,0,200,65)),b.crop((0,0,200,65)))
    assert top.getbbox()==(32,32,48,48), ('Not an isolated changed H glyph',top.getbbox())
    original=run('rbc-mini')
    modified=run('rbc-font-test')
    print('CHECK genuine_HiSoft_HELLO PASS')
    print('CHECK font_glyph_changed PASS')
    print('CHECK original_CHARS_restored PASS')
    print('CHECK real_ZX_UX_kernel PASS')
