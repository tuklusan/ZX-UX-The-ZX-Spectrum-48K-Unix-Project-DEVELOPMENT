rbc scratch proof — 22 October 2026
===================================

No ZX-UX repository files were changed. All outputs are in this scratch lab.

rbc.py has the requested header comment: "adapted from hisoft compiler".

This is NOT yet a general-purpose Sinclair BASIC compiler. It packages
ONLY the previously authenticated 44-byte HiSoft v1.1 'PRINT "HELLO"'
machine code. The compiler emits a native ZX-UX SSX1 header, relocates
7 known internal address references, and embeds a 768-byte 8x8 font.

The entry wrapper:
- Calls ZX-UX _screen to claim the screen (syscall number 39)
- Saves the CHARS system variable at 0x5C36
- Points CHARS to embedded font table minus 256
- Invokes the authentic compiled HiSoft entry point
- Restores CHARS and releases the screen
- Exits with ZX-UX _exit, status 0

Tests with the frozen real ZX-UX kernel (RVM):
- Original ROM 8x8 font: boot, load, PRINT "HELLO", exit 0: PASS
- Test font with 'H' overwritten to full block: glyph visibly changes: PASS
- SSX1 headers/relocation lists validated using frozen rld.py: PASS

The real user's custom font32 was not found in the project archive or
uploads. We tested the mechanism with the Spectrum 8x8 ROM font and a
modified test glyph. No claim about the final font32 appearance is made.

A full rbc would use Melissa O'Neill's independently written pyhsb Python
compiler (MIT License, copyright 2026 Melissa O'Neill) to implement the
Sinclair BASIC frontend. Its source is not bundled here. pyhsb requires
an authentic user-supplied HiSoft BASIC tape and Spectrum ROM. Incorporating
pyhsb code requires preserving LICENSE.txt and its copyright notice.

General-purpose SSX relocation, ROM/system-variable dependencies, input,
sound, UDG, array/data support, memory ownership, and games are UNPROVEN.
For unknown HiSoft binaries this prototype rejects conversion rather than
assuming relocation works.

Example (from within lab, using user-supplied original HiSoft generated binary):
python rbc.py ../out/hisoft-mini-65324.bin --font32 rom-font-test.bin -o rbc-mini.ssx --tzx rbc-mini.tzx

There is no verified generalized .bas -> .ssx path yet.
