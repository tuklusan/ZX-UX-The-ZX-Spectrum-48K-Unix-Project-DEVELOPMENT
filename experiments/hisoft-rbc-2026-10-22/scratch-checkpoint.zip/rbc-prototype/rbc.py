#!/usr/bin/env python3
# adapted from hisoft compiler
"""Scratch-only rbc experiment, not a general-purpose compiler.

Uses genuine HiSoft v1.1 output as input. The only supported byte sequence is
our independently captured HELLO sample. All other programs fail closed.
Embeds a 768-byte Spectrum 8x8 font in the native SSX process, claims the
screen, changes CHARS during execution, then restores and releases the screen.

Future rbc work can substitute the MIT-licensed pyhsb frontend after it is
acquired and inspected; this experiment does NOT bundle or adapt its source.
"""
from __future__ import annotations
import argparse
import hashlib
import struct
import sys
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRATCH / 'work' / 'sdk'))
import rld
import rtap

EXPECTED_HELLO_SHA256=hashlib.sha256(bytes.fromhex(
    'cd53ff2158ff226c5ccd47ff050048454c4c4f3e0dd7215827d9c9e14e234623545d09e5c33c203e02c30116')).digest()

class Emitter:
    def __init__(self):
        self.code=bytearray()
        self.fixups=[]
    def emit(self,*x): self.code.extend(x)
    def word(self,n): self.code.extend(struct.pack('<H', n&0xffff))
    def reloc_word(self,relative_address):
        self.fixups.append(len(self.code)); self.word(relative_address)
    def ldhln(self,n): self.emit(0x21);self.word(n)
    def lda(self,n): self.emit(0x3e,n)
    def call(self,n): self.emit(0xcd);self.word(n)
    def callrel(self,rel): self.emit(0xcd);self.reloc_word(rel)
    def ldhlwordfrom(self,addr): self.emit(0x2a);self.word(addr)
    def ldhlwordfromrel(self,rel): self.emit(0x2a);self.reloc_word(rel)
    def ldwordhl(self,addr): self.emit(0x22);self.word(addr)
    def ldwordhlrel(self,rel): self.emit(0x22);self.reloc_word(rel)

def generate(raw,font):
    assert len(font)==768
    if len(raw)!=44 or hashlib.sha256(raw).digest()!=EXPECTED_HELLO_SHA256:
        raise ValueError('Only the real 44-byte HiSoft HELLO trial is supported; unsafe to guess relocation sites')
    e=Emitter()
    e.ldhln(1);e.lda(39);e.call(0x6003)      # _screen claim
    e.ldhlwordfrom(0x5c36)                     # CHARS
    old_chars_store=len(e.code)+1;e.ldwordhlrel(0)  # patch old_chars address
    font_ptr=len(e.code)+1;e.emit(0x21);e.reloc_word(0) # CHARS = font_addr - 256
    e.ldwordhl(0x5c36)
    hello_call=len(e.code)+1;e.callrel(0)
    old_chars_load=len(e.code)+1;e.ldhlwordfromrel(0)
    e.ldwordhl(0x5c36)
    e.ldhln(0);e.lda(39);e.call(0x6003)   # _screen release
    e.ldhln(0);e.lda(1);e.call(0x6003)    # _exit
    e.emit(0x76)
    hello_off=len(e.code)
    e.code.extend(raw)
    old_chars_off=len(e.code)
    e.word(0)
    font_off=len(e.code)
    e.code.extend(font)
    # Repair initial symbolic placeholders; reloc records are already present.
    for off, val in [(old_chars_store,old_chars_off),(font_ptr,font_off-256),
                     (hello_call,hello_off),(old_chars_load,old_chars_off)]:
        e.code[off:off+2]=struct.pack('<H',val&0xffff)
    # Exact address dependent references inside the genuine 44-byte HiSoft code
    # identified during the prior two-address inspection of this specific binary.
    for original_offset,orig_target in [(1,39),(4,44),(10,27)]:
        at=hello_off+original_offset
        e.code[at:at+2]=struct.pack('<H',hello_off+orig_target)
        e.fixups.append(at)
    # original offset 7 is a fixed 0x5C6C ROM data-pointer, NOT a relocation.
    fixups=sorted(e.fixups)
    stream=rld.reloc_stream(fixups)
    hdr=b'SSX1'+struct.pack('<BBHHHHHH',0,20,len(e.code),0,384,0,0,len(fixups))
    ssx=hdr+struct.pack('<H',rld.fletcher16(hdr+e.code+stream))+e.code+stream
    assert rld.parse_ssx(ssx)['relocs']==fixups
    return ssx, {'wrapper':hello_off,'font_offset':font_off,'old_chars_offset':old_chars_off,'relocations':fixups}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('hisoft_bin',type=Path,help='genuine 44-byte HiSoft HELLO output, for first trial')
    ap.add_argument('--font32',type=Path,required=True,help='768-byte 8x8 Spectrum font, printable chars 32-127')
    ap.add_argument('-o','--output',type=Path,required=True)
    ap.add_argument('--tzx',type=Path,help='optional ZX-UX loader-compatible tape')
    a=ap.parse_args()
    font=a.font32.read_bytes()
    if len(font)!=768: ap.error('font32 must have 768 bytes, codes 32-127, eight bytes each')
    try: ssx,info=generate(a.hisoft_bin.read_bytes(),font)
    except ValueError as e: ap.error(str(e))
    a.output.write_bytes(ssx)
    if a.tzx:
        head,body=rtap.records(ssx, a.output.stem[:10])
        title=b'ZX-UX rbc scratch'
        rtap.write(str(a.tzx),b'ZXTape!\x1a\x01\x14'+bytes([0x30,len(title)])+title,[(1000,head),(2000,body)])
    print(f'rbc scratch: {a.output} ({len(ssx)} bytes), relocations {len(info["relocations"])}; '
          f'font {len(font)} bytes; HELLO @{info["wrapper"]}')
if __name__=='__main__':main()
