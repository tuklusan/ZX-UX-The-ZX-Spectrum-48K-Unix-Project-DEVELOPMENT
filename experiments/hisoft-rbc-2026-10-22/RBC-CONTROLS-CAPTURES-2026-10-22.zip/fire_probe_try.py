import sys,time,hashlib
from pathlib import Path
root=Path('/mnt/data/rbc-development/repo'); sys.path[:0]=[str(root/'dist/sdk/bin/py'),'/mnt/data/rbc-work/experiments/hisoft-rbc-2026-10-22/stage']
import rvm,zxux
from keyboard_ula import idle_ear_high
ssx=Path('/mnt/data/rbc-next/output/25-galaxians.ssx');system=root/'dist/zx-ux/tzx/ZX-UX.tzx'
opts=rvm.Options();opts.prog=str(ssx);opts.system=str(system);opts.headless=True
r=rvm.Runner(opts);t=time.time();r.start();idle_ear_high(r.session.m)
for _ in range(9000):
 r.frame()
 if r.fg and r.fg.started is not None:break
else:raise RuntimeError('no start')
for _ in range(70): r.frame()
r.session.kb.add([('press',zxux.char_keys(' '),30)])
for _ in range(100): r.frame()
bitmap,_=r.picture();
for x in range(20,160):
 count=sum(bool(bitmap[(((y&0xC0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(x//8))] & (0x80>>(x%8))) for y in range(40,180));
 if count>65: print('START vertical',x,count)
print('start after',round(time.time()-t,1),'started frame',r.fg.started, 'why',r.why)
r.session.kb.add([('press',zxux.char_keys('m'),110)])
max_vals=[]; all_screens=[]
for fr in range(150):
 r.frame();bitmap,_=r.picture()
 counts=[]
 for x in range(70,210):
  count=sum(bool(bitmap[(((y&0xC0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(x//8))] & (0x80>>(x%8))) for y in range(40,180))
  counts.append((count,x))
 m=max(counts);max_vals.append((fr,*m));
 if m[0]>65:
  all_screens.append((fr,m));
  if len(all_screens)<6: rvm.write_png(bitmap,f'/mnt/data/rbc-next/fire-{fr}.png',r.picture()[1])
print('TIME',time.time()-t,'max',sorted(max_vals,key=lambda x:x[1],reverse=True)[:20], 'detected',all_screens[:60]);print('last',r.fg.status,r.session.m.frame)
