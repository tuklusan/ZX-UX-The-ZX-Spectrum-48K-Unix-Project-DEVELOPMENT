import sys,time,hashlib,zipfile
from pathlib import Path
root=Path('/mnt/data/rbc-development/repo'); sys.path[:0]=[str(root/'dist/sdk/bin/py'),'/mnt/data/rbc-work/experiments/hisoft-rbc-2026-10-22/stage']
import rvm,zxux
from frame_probe import screen_letters
from keyboard_ula import idle_ear_high
archive=root/'experiments/hisoft-rbc-2026-10-22/rbc-sinclair-font-checkpoint-2026-10-22.zip'
with zipfile.ZipFile(archive) as z: font=z.read('rbc/font32.bin')
ssx='/mnt/data/rbc-next/output/25-galaxians.ssx';system=str(root/'dist/zx-ux/tzx/ZX-UX.tzx')

def measure(shoot):
 opts=rvm.Options();opts.prog=ssx;opts.system=system;opts.headless=True
 r=rvm.Runner(opts);r.start();idle_ear_high(r.session.m)
 for i in range(9000):
  r.frame()
  if r.fg and r.fg.started is not None:break
 else:raise RuntimeError('not started')
 for i in range(70):r.frame()
 r.session.kb.add([('press',zxux.char_keys(' '),30)])
 for i in range(100):r.frame()
 initial,_=r.picture();text=screen_letters(initial,font)
 print(shoot,'score before',repr(text[0]),'ship',repr(text[21]))
 if shoot:r.session.kb.add([('press',zxux.char_keys('m'),110)])
 maxes=[];points=[];scores=[]
 for fr in range(150):
  r.frame();pic,border=r.picture()
  column=143;mask=0x80>>(column%8)
  count=sum(bool(pic[(((y&0xc0)<<5)|((y&7)<<8)|((y&0x38)<<2)|(column//8))]&mask) for y in range(40,180))
  maxes.append(count)
  if count>=130: points.append(fr)
  if fr%20==0:scores.append((fr,screen_letters(pic,font)[0]))
 print(shoot,'max',max(maxes),'>=130 frames',points[:50],'num',len(points),'scores',scores)
 return max(maxes),len(points)
if __name__=='__main__': print('result',measure(False),measure(True))
