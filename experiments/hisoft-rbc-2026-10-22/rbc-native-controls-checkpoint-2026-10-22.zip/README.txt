ZX-UX RBC native 48K development checkpoint, October 22, 2026.
Complete experimental compiler, original-input SHA-256 checks, genuine
native ZX-UX frame captures, two games from text and tape source inputs,
other successfully compiled SSX1 programs, local test source, and 121
individual compilation outcomes. All original BASIC source files remain
unchanged in src/bonus/60-programs in the development repository.

Upstream compiler: tuklusan/Python-BASIC-Compiler-for-ZX-Spectrum-Hisoft
commit: 7cc87dafb58fcf5632b7190320dd11c30b4fe961
Font source: tuklusan/font8x8
commit: 8e279d2d864e79128e96188a6b9526cfa3fbfef9
Kernel tape: dist/zx-ux/tzx/ZX-UX.tzx
ROM: src/zx-ux-sdk/rom/48.rom
Test harness uses an idle-high EAR bit for inactive cassette input so
keyboard port comparisons in the original programs behave as intended.
This is an experimental runner change, not a production kernel patch.

Host Python tests: 34 passed. Full collection: 16 / 121 compiled.
Galaxians starts and moves left/right in native test, with SPACE,z,x,m.
Invaders starts and responds to the tested controls, though visual and
full gameplay match to the original Sinclair program remains unfinished.
The two original Invaders sprite glyphs checked against real screen cells
have the same eight source bitmap bytes, but frame positions and colors
require further comparison. No game parity declaration is made here.

The SHA256SUMS.txt lists all payload bytes inside this archive.
