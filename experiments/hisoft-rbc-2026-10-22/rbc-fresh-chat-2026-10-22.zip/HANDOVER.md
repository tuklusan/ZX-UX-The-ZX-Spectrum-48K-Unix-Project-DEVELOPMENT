# ZX-UX rbc fresh-chat handover — 2026-10-22

## Goal
Develop `rbc`, a Python Sinclair BASIC-to-ZX-UX SSX1 command-line compiler
based on Melissa O'Neill's `pyhsb` implementation of HiSoft BASIC v1.1.
Embed the 768-byte VGA 8x8 `font32` and 21 process-local UDG glyphs.
The primary visual and control goals are faithful Galaxians and Invaders,
then the other 58 historical BASIC programs. Avoid re-writing the games into C48.

## Permanent storage: GitHub
Repository: `tuklusan/ZX-UX-The-ZX-Spectrum-48K-Unix-Project-DEVELOPMENT`
Branch: `main`, public; do not assume any old container or clone survives.
The latest prior known commit was `d603c05500e34122662a4486078010881c6534a5`.
The current checkpoint ZIP is under
`experiments/hisoft-rbc-2026-10-22/` at GitHub; read the live branch first.
Other saved ZIPs there are `scratch-checkpoint.zip` and `rbc-pyhsb-stage.zip`.
Earlier experimental GitHub commits were `162b73cb...`, `66afb741...`.
The current ZIP supersedes older copies of `rbc/rbc.py`, `memory_safety.py`,
and the standalone keyboard test; retain older trials for regression.

## Input and compiler sources
Upstream Python HiSoft compiler: `https://github.com/imneme/pyhsb`
Exact revision: `7cc87dafb58fcf5632b7190320dd11c30b4fe961`.
It is MIT-licensed, Copyright 2026 Melissa O'Neill. Retain its license
and attribution when preparing an integrated `rbc` distribution.
The `rbc.py` file starts with the user-requested comment
`# adapted from hisoft compiler`.
Original HiSoft v1.1 Side A tape: use the user's authentic tape or the
public v1.1 48K TAP referenced in the GitHub test workflow.
SHA256 of original uploaded Side A TZX:
`08fe8de7acd17e20bee6a0399c850143b5a64b19797a9fc4109d2e919cf37175`.
48K ROM is available under `src/zx-ux-sdk/rom/48.rom` on GitHub.
ROM SHA256 seen in scratch:
`d55daa439b673b0e3f5897f99ac37ecb45f974d1862b4dadb85dec34af99cb42`.
The Python front-end must use the 48K HiSoft v1.1 option; side B v1.2
is a 128K compiler and is not our native 48K compiler.

## Tested, and limits
- Real ZX-UX kernel ran genuine HiSoft `PRINT "HELLO"`, emitted `HELLO`,
  and exited with status zero. The generated code includes VGA font setup.
- Current `rbc` source path builds `inkey-poll.bas` into a 1,562-byte SSX1.
  Regeneration reproduced saved `inkey.ssx` byte-for-byte.
  The ZX-UX kernel exits with status zero on the delayed `z` key test.
  `INKEY$` is immediate, unbuffered keyboard state, never terminal input.
- Static memory checks: 16 test cases pass. Strict mode blocks risky
  `POKE`, `PEEK`, numeric `USR`, `RANDOMIZE USR`, `CLEAR`, and unsupported
  memory/I/O use. `--memory-policy review` is only for isolated trials.
- `rbc` sets `CHARS` (0x5C36) to the embedded VGA 8x8 font table and sets
  `UDG` (0x5C7B) to process-local glyph storage. Both are restored on
  ordinary return. More work is needed for early exits and interruptions.
- `rbc` compiles at three different addresses to infer relocation sites.
  All changed bytes must be explained by address shifts. This alone does
  not guarantee ZX-UX compatibility for every ROM call.
- Galaxians' HiSoft-generated code has displayed its recognizable original
  opening instruction screen under ZX-UX; correct game play is not proven.
- Invaders executes under ZX-UX but screen contents are still damaged.
  Neither game is yet faithful enough to declare complete.
- Latest GitHub Actions 60-program sweep completed in run `39870573164`.
  Exactly 7 of 121 tested inputs passed the compilation stage: `HELLO`,
  and six source tape variants for programs 07, 23, 25, 39, 50, and 53.
  The workflow was green because it collected failures rather than requiring
  every compilation to pass. Do not report 121 successful compilations.
  The other failures include Python exceptions, text input tokenization,
  compiler limitations, and missing BASIC line targets. The full JSON is
  in `runner-sweep/rbc-60-results.json`.
- Original BASIC corpus scan: 59 of 60 source tapes were readable using
  the generic tape parser; 52 had statements blocked by strict policy.
  The screen is conservative and includes cases still needing analysis.
- Earlier scratch source tests and the local regression suite passed:
  font differs from ROM 8x8, Galaxians/Invaders SSX1 relocation layout,
  HELLO on real ZX-UX kernel, and genuine v1.1 TZX-to-TAP extraction.

## Work order on restart
1. Read current GitHub main, this handover, and the checkpoint ZIP. Extract
   to isolated scratch, not into the active ZX-UX source tree.
2. Fetch the exact upstream `pyhsb` revision and retain `LICENSE.txt`.
   Use repo `src/zx-ux-sdk` modules and 48K ROM, plus the authentic v1.1 tape.
3. Run the existing tests, then add repeatable `INKEY$` tests for no key,
   a held key, delayed press, and release; output must not be buffered.
4. Fix the `.bas` input path using the genuine tokenized `.tap` files as
   reference. Never change the archived BASIC originals. Prioritize
   Galaxians (25) and Invaders (58). Their machine code can be produced
   from their original source tapes even while text reading is being fixed.
5. Review memory operations separately: memory-access policy must be tied
   to verified ROM and kernel behavior. Study `rcc` UDG and keyboard code
   as the target behavior reference, without depending on `c48lib`.
6. Run Galaxians and Invaders with realistic input sequences and compare
   genuine bitmap/attribute frames to their preserved original BASIC
   screenshots. Repair `rbc` and its runtime until timing, gameplay, and
   appearance match as closely as supported. Then tune using all 60.
7. Preserve useful source and test milestones on GitHub often. Before each
   push run the existing private checker using its complete banned list;
   never disable or weaken it. Confirm new remote main and tree afterward.

## Limits on changes
The user has lifted the repo development lock, but work still belongs in
`experiments/` until the new layout is ready. Later `rbc` is intended
next to `rcc` under `src/zx-ux-sdk`; `font32` is intended next to the
existing Spectrum SDK font file under `src`. The new RBC path should not
need `c48lib`. Do not delete it until dependent older ports are handled.
No archived original BASIC or existing system source was modified in
this experiment. Do not claim game parity from a compile or intro image.

## Rebuild example
After cloning live GitHub main to an isolated checkout, extract the new
checkpoint ZIP outside the checkout, then fetch upstream:
`git clone https://github.com/imneme/pyhsb pyhsb`
`git -C pyhsb checkout --detach 7cc87dafb58fcf5632b7190320dd11c30b4fe961`
The file `scratch/rbc/rbc.py` accepts:
`python scratch/rbc/rbc.py PROGRAM.bas --frontend pyhsb --sdk SDKDIR --rom SDKDIR/rom/48.rom --tape HISOFT_V11_SIDE_A.tzx -o PROGRAM.ssx --report PROGRAM.json`
Use `--memory-policy review` only when investigating a flagged program
in an isolated emulator. Keep the warnings with any generated output.
