#!/bin/sh
set -eu
DEST="${1:-pyhsb}"
if test -e "$DEST"; then
    echo "destination already exists; refusing overwrite" >&2
    exit 1
fi
git clone https://github.com/imneme/pyhsb.git "$DEST"
(cd "$DEST" && git checkout --detach 7cc87dafb58fcf5632b7190320dd11c30b4fe961)
test -f "$DEST/LICENSE.txt"
test -f "$DEST/compiler.py"
echo "pyhsb external dependency acquired at $DEST"
