from pathlib import Path
p=Path('/mnt/data/rbc-resume-20261022/rbc/rbc.py')
s=p.read_text()
s=s.replace('import os\n', 'import os\nimport re\n')
needle='def _compile_three(src:Path, frontend:Path, tape:Path, romfile:Path,\n'
assert needle in s
addition='''def _source_program(src: Path, source, kw, fp):
    """Read numbered archival .bas listings, preserving Spectrum byte escapes.

    Historical text uses {90} for a single byte in the Spectrum character
    set. The generic plain-text reader treats those four characters literally.
    It also misses AND/OR/TO/THEN immediately following a decimal digit.
    Original .tap inputs are still handled by the upstream token reader.
    """
    if src.suffix.lower() != '.bas':
        return source.read_program(src, kw, fp)
    import tap as spectrum_tap
    rows=[]
    for file_line, raw in enumerate(src.read_text(encoding='latin-1').splitlines(),1):
        raw=raw.strip()
        if not raw:continue
        match=re.match(r'^(\\d+)\\s+(.*)$',raw)
        if not match:
            raise ValueError(f'{src.name}: invalid BASIC text line {file_line}')
        number=int(match.group(1)); body=match.group(2)
        # Preserve quoted text and REMs verbatim. Only adjust digit-adjacent
        # language words where the plain-text lexer lacks a word boundary.
        chunks=[];i=0;quoted=False;comment=False
        while i < len(body):
            c=body[i]
            if not quoted and not comment and c=='"': quoted=True
            elif quoted and c=='"': quoted=False
            if not quoted and not comment and body[i:i+3].upper()=='REM':
                left=(i==0 or not body[i-1].isalnum())
                right=(i+3==len(body) or not body[i+3].isalnum())
                if left and right: comment=True
            if not quoted and not comment and c.isdigit():
                for word in ('THEN','STEP','AND','OR','TO'):
                    if body.startswith(word,i+1):
                        chunks.append(c+' ');i+=1;break
                else:
                    chunks.append(c);i+=1
                continue
            chunks.append(c);i+=1
        encoded=source.tokenize_line(''.join(chunks),kw)
        # Replace archival {HH} byte notation, including UDG character codes
        # inside quoted strings and control bytes kept in REM comments.
        encoded=re.sub(rb'\\{([0-9A-Fa-f]{2})\\}',
                       lambda m: bytes((int(m.group(1),16),)),encoded)
        rows.append((number,source.hide_numbers(encoded,fp)+b'\\x0d'))
    if not rows:raise ValueError(f'{src.name}: empty BASIC listing')
    numbers=[n for n,_ in rows]
    if len(set(numbers))!=len(numbers):
        raise ValueError(f'{src.name}: duplicate BASIC line numbers')
    return src.stem[:10],spectrum_tap.join_lines(sorted(rows))


'''
s=s.replace(needle,addition+needle)
s=s.replace('name, program = source.read_program(src,kw,initial.fp)','name, program = _source_program(src,source,kw,initial.fp)')
p.write_text(s)
