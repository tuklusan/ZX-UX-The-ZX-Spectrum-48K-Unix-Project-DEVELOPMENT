#!/usr/bin/env python3
"""Inspect authentic historical tapes for memory-sensitive BASIC commands.

The report records suspicious operations; it does not claim running games.
"""
from collections import Counter
import json
from pathlib import Path
import sys
import zipfile
sys.path.insert(0,str(Path(__file__).parent/'rbc'))
import rbc
import memory_safety

SOURCE=Path('/mnt/data/ZX-UX-GITHUB-REPO-beta-0.2.0.zip')
BASE='ZX-UX-GITHUB-REPO/src/bonus/60-programs/'
TOK={0xf4:'POKE',0xc0:'USR',0xbe:'PEEK',0xfd:'CLEAR',0xf9:'RANDOMIZE',
     0xbf:'IN',0xdf:'OUT',0xea:'REM',0xeb:'FOR',0xcc:'TO',
     0xef:'LOAD',0xf8:'SAVE',0xd6:'VERIFY',0xd5:'MERGE'}


def tape_lines(tapdata):
    i=0
    while i+2<=len(tapdata):
        n=int.from_bytes(tapdata[i:i+2],'little');i+=2
        block=tapdata[i:i+n];i+=n
        if len(block)!=n:raise ValueError('truncated tape record')
        if n<3 or block[0]!=0xff:continue
        d=block[1:-1]
        # BASIC stored program lines, big endian line numbers, little endian sizes.
        pos=0;items=[]
        while pos+4<=len(d):
            line=d[pos]<<8|d[pos+1]
            size=int.from_bytes(d[pos+2:pos+4],'little');pos+=4
            if not (0<line<=9999 and 0<size<=2048 and pos+size<=len(d)):
                items=[];break
            chunk=d[pos:pos+size];pos+=size
            if chunk[-1]!=13:items=[];break
            items.append((line,chunk))
        if items and (pos==len(d) or len(d)-pos<80):return items
    raise ValueError('no standard BASIC program found in tape')


def run():
    found=[];bad=[]
    with zipfile.ZipFile(SOURCE) as z:
        tzxs=sorted(n for n in z.namelist() if n.startswith(BASE)
                    and '/BASIC/' in n and n.endswith('.tzx'))
        if len(tzxs)!=60:raise RuntimeError(f'expected 60 TZX files, got {len(tzxs)}')
        for path in tzxs:
            game=path[len(BASE):].split('/')[0]
            try:
                tzx=Path('/tmp/scan-basic.tzx')
                tzx.write_bytes(z.read(path))
                lines=tape_lines(rbc._tap_from_tzx(tzx))
                findings=memory_safety.analyze_lines(lines,TOK)
                data=memory_safety.summarize(findings)
                found.append({'program':game,'lines':len(lines),**data})
            except Exception as e:
                bad.append({'program':game,'error':str(e)})
    target=Path(__file__).parent/'test-out/memory-corpus.json'
    report={'sources':len(tzxs),'readable':len(found),'unreadable':bad,
            'severity_totals':dict(Counter(f['severity'] for game in found
                                           for f in game['findings'])),
            'memory_sensitive':sum(bool(g['findings']) for g in found),
            'unresolved_games':[g['program'] for g in found if g['counts']['block']],
            'programs':found}
    target.write_text(json.dumps(report,indent=2)+'\n')
    print('tapes',report['sources'],'readable',report['readable'],
          'sensitive',report['memory_sensitive'],'unresolved',len(report['unresolved_games']))
    print('severity_totals',report['severity_totals'])
    print('report',target)

if __name__=='__main__':run()
