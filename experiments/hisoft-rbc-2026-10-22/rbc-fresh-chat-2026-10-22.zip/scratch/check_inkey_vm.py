from pathlib import Path
import sys
sdk='/mnt/data/hisoft-ssx-lab/work/dist_sdk'
sys.path.insert(0,sdk)
import rvm
p=Path('/mnt/data/rbc-resume-20261022/out/inkey.ssx')
sys_tape='/mnt/data/hisoft-ssx-lab/inputs/ZX-UX.tzx'
for keys in ('', 'z', '{WAIT 20}z', '{WAIT 60}z'):
 print('TEST KEYS',repr(keys),flush=True)
 result=rvm.run_kernel(p,keys=keys,frames=300,system=sys_tape)
 print('RESULT',result.why,'status',result.fg.status,'frames',result.session.m.frame-result.start_frame,flush=True)
 screen,border=result.picture()
 from zxscreen import screen_text
 print(screen_text(screen)[:1050],flush=True)
