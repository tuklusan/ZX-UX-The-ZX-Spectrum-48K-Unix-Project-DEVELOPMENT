#!/usr/bin/env python3
"""Checks before BASIC memory operations can affect a ZX-UX process."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'rbc'))
from memory_safety import analyze_lines, summarize, enforce, MemoryBlocked
TOK={0xf4:'POKE',0xc0:'USR',0xbe:'PEEK',0xfd:'CLEAR',0xf9:'RANDOMIZE',
     0xbf:'IN',0xdf:'OUT',0xea:'REM',0xeb:'FOR',0xcc:'TO'}

def scan(*source):
 return analyze_lines([(i+1, data+b'\r') for i,data in enumerate(source)], TOK)

cases=[
 ((b'\xf4\xc0"a"+x,y',),('block','info')), # POKE UDG, USR string
 ((b'\xf4\xc0"{A2}"+x,y',),('block','info')),
 ((b'\xf4 23675,42',),('block',)),
 ((b'\xbe 23675',),('block',)),
 ((b'\xf4 16384,0',),('review',)),
 ((b'\xf9\xc0 32768',),('block','block')),
 ((b'\xfd 50000',),('block',)),
 ((b'\xea \xf4 23675,0',),()),
 ((b'\xf4 23675,0',b'\xea \xf4 23675,0'),('block',)),
 ((b'PRINT "POKE 23675"',),()),
 ((b'\xf9 10',),()),
 ((b'\xbf 65278',),('review',)),
 ((b'\xeb X=0\xcc 7:\xf4\xc0"{A2}"+X,A',),('info','info')),
 ((b'\xeb x=\xc0"a"\xcc\xc0"n"+7:\xf4 x,y',),('info','info','info')),
 ((b'\xf4\xc0"{A4}"+8,A',),('block','info')),
 ((b'\xf4\xc0"{A2}",A',),('info','info')),
]
for source,want in cases:
 f=scan(*source)
 assert tuple(x.severity for x in f)==want,(source,want,f)
 if 'block' in want:
  try:enforce(f,'strict')
  except MemoryBlocked as e: assert e.findings==f
  else:raise AssertionError('strict allowed unproven memory operation')
 else:enforce(f,'strict')
print(f'CHECK memory_guard_{len(cases)}_cases PASS')
