#!/usr/bin/env python3
"""Scratch tests for the pyhsb-backed native SSX1 output layer."""
from __future__ import annotations
import hashlib
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE/'rbc'))
sys.path.insert(0,str(ROOT/'work/dist_sdk'))
import rbc,rld,rvm


def test_pairs():
    for program,size,relocs in [('galaxians',7132,1010),('invaders',8436,1343)]:
        meta=__import__('json').loads((HERE/'test-out'/f'{program}.json').read_text())
        assert meta['machine_code']==size
        assert meta["relocations"]==relocs+7
        assert meta['font_bytes']==768
        assert meta['rom_and_system_variable_compatibility']=='unverified'
        parsed=rld.parse_ssx((HERE/'test-out'/f'{program}.ssx').read_bytes())
        assert len(parsed['relocs'])==relocs+7
        print(f'CHECK {program}_relocation_packaging PASS')


def test_font():
    font=(HERE/'rbc/font32.bin').read_bytes()
    rom=(ROOT/'inputs/48.rom').read_bytes()[0x3D00:0x4000]
    assert len(font)==len(rom)==768
    assert font!=rom
    print('CHECK vga8x8_not_rom_font PASS')


def test_hello():
    # Actual first HiSoft output. Construct a shifted variant ONLY to check
    # the relocation stage, not as an independently run HiSoft compiler pass.
    source=(ROOT/'out/hisoft-mini-65324.bin').read_bytes()
    assert len(source)==44
    shifted=bytearray(source)
    delta=-389
    for at in (1,4,10):
        v=int.from_bytes(shifted[at:at+2],'little')
        shifted[at:at+2]=((v+delta)&0xFFFF).to_bytes(2,'little')
    builds=[rbc.HiSoftBuild(source,65324,65324,0),
            rbc.HiSoftBuild(bytes(shifted),65324+delta,65324+delta,0)]
    ssx,report=rbc.build_ssx(builds,(HERE/'rbc/font32.bin').read_bytes(),rld)
    assert report['relocations']==10
    p=HERE/'test-out/hello.ssx';p.write_bytes(ssx)
    run=rvm.run_kernel(p,system=ROOT/'inputs/ZX-UX.tzx',frames=800)
    assert run.why=='exit' and run.fg.status==0,(run.why,run.fg.status)
    mem=run.session.m.mem
    assert (mem[0x5C36] | mem[0x5C37]<<8)==0x3C00
    assert (mem[0x5C7B] | mem[0x5C7C]<<8)==0xFF58, "UDG pointer not restored"
    screen,border=run.picture();rvm.write_png(screen,str(HERE/'test-out/hello.png'),border)
    print('CHECK real_kernel_hello_with_vga8x8 PASS')


def test_tzx():
    src=Path('/mnt/data/Hisoft BASIC Compiler v1.1 - Side A.tzx')
    if src.exists():
        b=rbc._tap_from_tzx(src)
        assert b and len(b)>12500
        print('CHECK genuine_v11_tzx_to_tap PASS')

if __name__=='__main__':
    test_pairs();test_font();test_hello();test_tzx()
