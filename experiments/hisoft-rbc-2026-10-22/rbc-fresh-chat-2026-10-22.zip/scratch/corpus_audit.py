#!/usr/bin/env python3
"""Read-only source preflight of all 60 historical Sinclair BASIC listings.

This is a screening report, NOT a claim of successful compilation or play.
"""
import collections
import json
import re
import sys
import zipfile
from pathlib import Path

ZIP=Path('/mnt/data/ZX-UX-GITHUB-REPO-beta-0.2.0.zip')
BASE='ZX-UX-GITHUB-REPO/src/bonus/60-programs/'
RULES={
 'memory_access':r'\b(?:POKE|PEEK|CLEAR|USR)\b',
 'raw_keyboard_ports':r'\b(?:IN|OUT)\s+\d+',
 'udg_data':r'\b(?:USR|DATA)\b|\{[0-9A-Fa-f]{2,3}\}',
 'floating_point':r'\b(?:SIN|COS|TAN|ASN|ACS|ATN|EXP|LN|SQR|PI|RND)\b',
 'beeper':r'\bBEEP\b',
 'tape_io':r'\b(?:SAVE|LOAD|VERIFY|MERGE)\b',
 'dynamic_branches':r'\b(?:GO\s*TO|GOTO|GO\s*SUB|GOSUB|RESTORE)\s+(?!\d+\b)',
 'string_eval':r'\bVAL\s+[A-Z][A-Z0-9]*\$',
 'screen_control':r'\b(?:CLS|PLOT|DRAW|CIRCLE|PAPER|INK|AT|BORDER)\b',
}


def run():
 with zipfile.ZipFile(ZIP) as z:
  paths=[p for p in z.namelist() if p.startswith(BASE) and re.search(r'/BASIC/\d\d-[^/]+\.bas$',p)]
  report=[]
  for path in sorted(paths):
   b=z.read(path)
   source=b.decode('latin-1').upper()
   flags=[name for name,pattern in RULES.items() if re.search(pattern,source)]
   report.append({'program':path.split('/')[-3], 'bytes':len(b),
                  'lines':sum(bool(line.strip()) for line in source.splitlines()),
                  'flags':flags,
                  'screen_font_note':'ROM font is replaced only for this process; UDGs are separate',
                  'compile':'not_run', 'zx_ux_gameplay':'not_run'})
  if len(report)!=60:raise ValueError(f'Expected 60 listings, found {len(report)}')
  summary=dict(collection_size=60,source='ZX-UX-GITHUB-REPO-beta-0.2.0.zip (CRLF edition)',
               meaning='static syntax screen only; compile and run status unknown',
               occurrences=dict(collections.Counter(flag for item in report for flag in item['flags'])),
               programs=report)
  target=Path(__file__).parent/'test-out/corpus-preflight.json'
  target.parent.mkdir(exist_ok=True);target.write_text(json.dumps(summary,indent=2)+'\n')
  print('CHECK 60_source_listings_read PASS')
  for key,value in sorted(summary['occurrences'].items()):print(f'{key}: {value}/60')
  print('Report:',target)

if __name__=='__main__':run()
