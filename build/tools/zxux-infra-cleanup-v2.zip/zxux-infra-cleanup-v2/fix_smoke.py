from pathlib import Path
p=Path.cwd() / 'build/tools/smoke_test.py'
s=p.read_text()
def change(old,new, count=1):
 global s
 assert s.count(old)==count,(old[:90],s.count(old))
 s=s.replace(old,new)
change("        (tools / 'basicpack.py').write_text('def package(*args): return 1\\n')", """        (tools / 'c48lib_build.py').write_text('''
from pathlib import Path
def build(sdk):
    out = Path(sdk) / 'lib/c48lib.ssa'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(b'test archive')
    return out
''')
        (tools / 'basicpack.py').write_text('def package(*args): return 1\\n')""")
change("        (tools / 'basicpack.py').write_text('def package(*args): return 1\\n')", """        (tools / 'basicpack.py').write_text('''
def package(source, stage):
    (stage / 'assets/basic-src').mkdir(parents=True, exist_ok=True)
''')""")
change("        self.assertEqual((self.dist/'bonus/60-programs/01-demo/BASIC/demo.bas').read_text(), '10 PRINT \"OK\"')", "        self.assertFalse((self.dist/'bonus').exists())")
start=s.index('    def test_bonus_has_only_numbered_programs_and_preview(self):')
end=s.index('    def test_only_forth_showcase_in_dist(self):',start)
s=s[:start]+'''    def test_original_collections_remain_source_only(self):
        source = self.src / 'assets/basic-src/original-sinclair-basic-collections/60-programs'
        (source / 'PROGRAMS.zip').write_bytes(b'historical source archive')
        (source / 'TOOLS').mkdir()
        (source / 'TOOLS/helper.py').write_text('pass')
        self.run_builder()
        self.assertFalse((self.dist / 'bonus').exists())
        self.assertFalse((self.dist / 'assets/basic-src/original-sinclair-basic-collections').exists())
        self.assertEqual((source / '01-demo/BASIC/demo.bas').read_text(), '10 PRINT "OK"')
        self.assertTrue((source / 'PROGRAMS.zip').exists())
        self.assertTrue((source / 'TOOLS/helper.py').exists())
        self.run_builder()
        self.assertFalse((self.dist / 'bonus').exists())

'''+s[end:]
change("{'examples', 'numerical-analysis', 'portable', 'ported'}", "{'examples', 'numerical-analysis'}")
change('    def test_existing_c48_gallery_survives_staged_rebuild(self):', '    def test_existing_c48_gallery_is_not_reused_in_clean_stage(self):')
change("        self.assertEqual(original.read_bytes(), b'existing RVM screenshot')", "        self.assertFalse(original.exists())")
change("        self.assertEqual((self.dist / 'THIRD-PARTY').read_text(), 'third party')", "        self.assertEqual((self.dist / 'THIRD-PARTY').read_text(), 'third party')\n        self.assertEqual((self.root / 'build/sdk/lib/c48lib.ssa').read_bytes(), b'test archive')")
start=s.index('    def test_missing_numbered_program_preserves_prior_dist(self):')
end=s.index('    def test_failure_preserves_dist(self):',start)
s=s[:start]+'''    def test_missing_c48_source_preserves_prior_dist(self):
        self.run_builder()
        target = self.dist / 'zx-ux/tzx/ZX-UX.tzx'
        before = target.read_bytes()
        import shutil
        shutil.rmtree(self.src / 'assets/c48-src')
        self.run_builder(ok=False)
        self.assertEqual(target.read_bytes(), before)

'''+s[end:]
p.write_text(s)
