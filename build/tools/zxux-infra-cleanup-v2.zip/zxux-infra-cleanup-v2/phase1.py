#!/usr/bin/env python3
"""ZX-UX surgical layout migration. Run from repository root once."""
from __future__ import annotations
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
assert (ROOT / 'build/build.py').is_file(), 'Run from ZX-UX repository root'

def change(path, old, new, count=1):
    p = ROOT / path
    txt = p.read_text(encoding='utf-8')
    assert txt.count(old) == count, f'{path}: expected {count} matches for {old!r}, got {txt.count(old)}'
    p.write_text(txt.replace(old, new), encoding='utf-8')


def move(src, dst):
    a, b = ROOT / src, ROOT / dst
    assert a.is_file() and not b.exists(), f'Move conflict {src} -> {dst}'
    b.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', 'mv', str(a), str(b)], check=True)

# 1. Live main has no tracked src/bonus files; remove local empty residue only.
stray = ROOT / 'src/bonus/60-programs/03-tug-of-war/BASIC'
if stray.is_dir() and not any(stray.iterdir()):
    for d in (stray, *stray.parents):
        if d == ROOT / 'src' or not d.is_dir() or any(d.iterdir()):
            break
        d.rmdir()

for folder, names in {'portable': ['calendar', 'pfbench', 'pfsieve'],
                      'ported': ['hufdemo', 'worms']}.items():
    for name in names:
        move(f'src/assets/forth-src/{folder}/{name}.fth',
             f'src/assets/forth-src/examples/{name}.fth')
    (ROOT / 'src/assets/forth-src' / folder).rmdir()

for name in ('FONT-SOURCE.txt', 'c48lib-font.asm', 'c48lib.asm', 'c48lib.h'):
    move('src/zx-ux-sdk/rb2ct/ports/c48lib/' + name,
         'src/zx-ux-sdk/rb2ct/c48lib/' + name)
(ROOT / 'src/zx-ux-sdk/rb2ct/ports/c48lib').rmdir()
(ROOT / 'src/zx-ux-sdk/rb2ct/ports').rmdir()

# 2. Package only the reorganized Forth sources, no duplicate bonus archive.
change('build/build.py',
       "FORTH_SHOWCASE_DIRS = ('examples', 'numerical-analysis', 'portable', 'ported')",
       "FORTH_SHOWCASE_DIRS = ('examples', 'numerical-analysis')")
change('build/build.py', "    copy_original_programs(originals, stage / 'bonus', no_cache)\n", '')
change('build/build.py', "    preserve_existing_c48_release(D, stage)\n", '')
change('build/build.py', "    forthbuild.build(B / 'sdk', stage / 'assets/forth-src', stage / 'assets/forth-bin')\n",
       "    forthbuild.build(B / 'sdk', stage / 'assets/forth-src', stage / 'assets/forth-bin')\n"
       "    # Git cannot record empty directories: these are the sole tracking markers.\n"
       "    for name in ('rb2ct', 'rb2ct-src', 'rb2ct-bin'):\n"
       "        placeholder = stage / 'assets' / name / '.gitkeep'\n"
       "        placeholder.parent.mkdir(parents=True, exist_ok=True)\n"
       "        placeholder.touch()\n"
       "    (stage / 'assets/basic-src/README.txt').write_text(\n"
       "        'These original BAS/TZX files run under ZX Spectrum 48K BASIC, not ZX-UX; their accepted ZX-UX ports are in rbc-bin and future rb2ct-bin.\\n', encoding='utf-8')\n"
       "    for rel in ('assets/forth-bin/results.tsv', 'assets/fortran-bin/samples/results.tsv',\n"
       "                'assets/pascal-bin/samples/results.tsv'):\n"
       "        (stage / rel).unlink(missing_ok=True)\n")
# In a selective local rebuild, do not publish the report files either.
change('build/build.py', "        for rel in updates:\n",
       "        for rel in ('assets/forth-bin/results.tsv', 'assets/pascal-bin/samples/results.tsv'):\n"
       "            (stage / rel).unlink(missing_ok=True)\n"
       "        for rel in updates:\n")

# 3. RBC sources: accepted-only copies in both source categories.
# basic-src: original ZX Spectrum BASIC BAS+TZX; rbc-src: accepted port sources.
p = ROOT / 'src/zx-ux-sdk/tools/basicpack.py'
s = p.read_text(encoding='utf-8')
start = s.index("            target = stage / 'assets/basic-src' / collection / game.name")
end = s.index("            executable = game / 'bin' / (game.name + '.ssx')", start)
assert 'screenshots/basic-original' in s[start:end]
s = s[:start] + s[end:]
needle = "            data = executable.read_bytes()\n"
assert s.count(needle) == 1
replacement = ("            # Only accepted binaries have released source listings.\n"
               "            basic = stage / 'assets/basic-src' / collection / game.name\n"
               "            rbc = stage / 'assets/rbc-src' / collection / game.name\n"
               "            basic.mkdir(parents=True, exist_ok=True)\n"
               "            rbc.mkdir(parents=True, exist_ok=True)\n"
               "            for original in bas + tzx:\n"
               "                if original.is_symlink():\n"
               "                    raise ValueError('linked BASIC input')\n"
               "                shutil.copyfile(original, basic / original.name)\n"
               "            for original in bas:\n"
               "                shutil.copyfile(original, rbc / original.name)\n"
               + needle)
s = s.replace(needle, replacement)
p.write_text(s, encoding='utf-8')

# 4. Pascal distribution aliases, without renaming the archival source collection.
ALIASES = {
    'recovered_21_fibonacci_array': 'fibarray',
    'recovered_course_030_fibonacci_optimized': 'fibopt',
    'recovered_course_040_fibonacci_large': 'fiblarge',
}
def alias(name):
    return ALIASES.get(name, name.removeprefix('f77s_'))

p = ROOT / 'src/zx-ux-sdk/tools/pascalpack.py'
s = p.read_text(encoding='utf-8')
s = s.replace("            case = pas.stem\n", "            case = pas.stem.removeprefix('f77s_')\n"
              "            case = {'recovered_21_fibonacci_array': 'fibarray',\n"
              "                    'recovered_course_030_fibonacci_optimized': 'fibopt',\n"
              "                    'recovered_course_040_fibonacci_large': 'fiblarge'}.get(pas.stem, case)\n")
s = s.replace("            shutil.copyfile(pas, dest / pas.name)\n",
              "            shutil.copyfile(pas, dest / (case + '.pas'))\n")
assert "(case + '.pas')" in s and "case = pas.stem.removeprefix" in s
p.write_text(s, encoding='utf-8')

# Only rpc's sample catalogue uses these Pascal names; FORTRAN names must not change.
p = ROOT / 'build/tools/compiler_portfolio.py'
s = p.read_text(encoding='utf-8')
a = s.index("    'rpc': [")
b = s.index("    'rfortranc': [", a)
part = s[a:b]
for name in ('recovered_21_fibonacci_array',
             'recovered_course_030_fibonacci_optimized',
             'recovered_course_040_fibonacci_large'):
    assert name in part
    part = part.replace(name, alias(name))
part = re.sub(r'f77s_(burk[a-z0-9]+|machar)', r'\1', part)
s = s[:a] + part + s[b:]
p.write_text(s, encoding='utf-8')

# Build the rb2ct-specific assembly archive into the source SDK lib now,
# then rebuild the identical archive in the staged SDK on every normal build.
# This archive is separate from libc48.ssa: it has its own unresolved glyph hooks.
libgen = ROOT / 'src/zx-ux-sdk/tools/c48lib_build.py'
assert not libgen.exists(), 'c48lib_build.py already exists; reconcile instead of overwrite'
libgen.write_text('''#!/usr/bin/env python3
"""Assemble rb2ct C48 support into lib/c48lib.ssa (separate from libc48.ssa)."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ras, rld

def build(sdk=ROOT):
    sdk = Path(sdk)
    source = sdk / 'rb2ct/c48lib'
    objects = []
    for filename in ('c48lib.asm', 'c48lib-font.asm'):
        path = source / filename
        asm = path.read_text(encoding='utf-8')
        if filename == 'c48lib-font.asm':
            asm = '        global c48_vga_font\\n' + asm
        objects.append((path.stem + '.sso', ras.assemble_text(asm, str(path))))
    out = sdk / 'lib/c48lib.ssa'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(rld.write_archive(objects))
    return out

if __name__ == '__main__':
    print(build())
''', encoding='utf-8')
change('build/build.py',
       'import osbuild, turbo_boot_build, c48build, sdkpack, basicpack, forthbuild, pascalpack, fortranpack',
       'import osbuild, turbo_boot_build, c48build, sdkpack, basicpack, forthbuild, pascalpack, fortranpack, c48lib_build')
change('build/build.py',
       "    shutil.copytree(S / 'zx-ux-sdk', B / 'sdk', ignore=no_cache)\n",
       "    shutil.copytree(S / 'zx-ux-sdk', B / 'sdk', ignore=no_cache)\n"
       "    c48lib_build.build(B / 'sdk')\n")
# Building into src/lib is intentional for the checked-in SDK; normal builds
# rebuild under build/sdk so they do not modify tracked sources.
subprocess.run([sys.executable, '-B', str(libgen)], check=True)
# 5. Generate complete release screenshot galleries from actual binaries.
gallery = ROOT / 'build/tools/asset_gallery.py'
assert not gallery.exists(), 'asset_gallery.py already exists; reconcile instead of overwrite'
shutil.copyfile(Path(__file__).with_name('asset_gallery.py'), gallery)
change('build/tools/gallery_index.py',
       "def write_index(engines=('rvm', 'fuse')):\n",
       "def write_index(engines=('rvm', 'fuse')):\n"
       "    complete = engines == ('rvm', 'fuse')\n"
       "    if complete:\n"
       "        from asset_gallery import finalize\n"
       "        finalize()\n")
change('build/tools/gallery_index.py',
       "    for directory, title in COMPILERS:\n",
       "    for directory, title in COMPILERS:\n"
       "        if complete:\n"
       "            directory = {'c48': 'c48-bin', 'rbc': 'rbc-bin',\n"
       "                         'rfc': 'forth-bin', 'rpc': 'pascal-bin',\n"
       "                         'rfortranc': 'fortran-bin'}[directory]\n")
change('build/tools/gallery_index.py',
       "                if engine == 'fuse' and directory == 'rfortranc':\n"
       "                    continue  # No valid real Fuse capture for fast-exiting programs.\n", '')

print('PHASE 1 COMPLETE: source moves and release generators updated')
