#!/usr/bin/env python3
"""Parallelize the two RVM capture entry points without duplicating code."""
from pathlib import Path

def apply(path, src, dst):
    p=Path(path)
    text=p.read_text()
    n=text.count(src)
    if n != 1:
        raise RuntimeError(f'{path}: expected one matching section, found {n}')
    p.write_text(text.replace(src,dst))

p='build/tools/portfolio.py'
apply(p,'import argparse\n','import argparse\nfrom concurrent.futures import ProcessPoolExecutor, as_completed\n')
apply(p,
"    p.add_argument('--frames', type=int, default=1500)\n    args = p.parse_args()\n",
"    p.add_argument('--frames', type=int, default=1500)\n    p.add_argument('--jobs', type=int, default=12)\n    args = p.parse_args()\n    if not 1 <= args.jobs <= 16:\n        p.error('--jobs must be 1..16')\n")
apply(p,
'''    for name, category, config in captures():
        if only is not None and name not in only:
            continue
        found.add(name)
        try:
            run_one(name, category, config, args.frames)
        except Exception as exc:
            print('RVM FAIL:', name, exc, file=sys.stderr)
            failures.append(name)
    for names in PAIRS:
        identifier = '-'.join(names)
        if only is None or identifier in only:
            try:
                run_pair(names)
            except Exception as exc:
                print('RVM FAIL:', identifier, exc, file=sys.stderr)
                failures.append(identifier)
''',
'''    tasks = []
    for name, category, config in captures():
        if only is not None and name not in only:
            continue
        found.add(name)
        tasks.append((name, run_one, (name, category, config, args.frames)))
    for names in PAIRS:
        identifier = '-'.join(names)
        if only is None or identifier in only:
            tasks.append((identifier, run_pair, (names,)))
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        pending = {pool.submit(fn, *params): name for name, fn, params in tasks}
        for future in as_completed(pending):
            name = pending[future]
            try:
                future.result()
            except Exception as exc:
                print('RVM FAIL:', name, exc, file=sys.stderr)
                failures.append(name)
''')

p='build/tools/basic_portfolio.py'
apply(p,'import argparse\n','import argparse\nfrom concurrent.futures import ProcessPoolExecutor, as_completed\n')
apply(p,
"    p.add_argument('--frames', type=int, default=1500)\n    args = p.parse_args(argv)\n",
"    p.add_argument('--frames', type=int, default=1500)\n    p.add_argument('--jobs', type=int, default=12)\n    args = p.parse_args(argv)\n    if not 1 <= args.jobs <= 16:\n        p.error('--jobs must be 1..16')\n")
apply(p,
'''    for collection, ssx, label in cases():
        if wanted is not None and ssx.stem not in wanted:
            continue
        found.add(ssx.stem)
        try:
            run_one(collection, ssx, label, args.frames)
        except Exception as e:
            print('RBC RVM FAIL:', ssx.stem, str(e), file=sys.stderr, flush=True)
            failures.append(ssx.stem)
''',
'''    tasks = []
    for collection, ssx, label in cases():
        if wanted is not None and ssx.stem not in wanted:
            continue
        found.add(ssx.stem)
        tasks.append((collection, ssx, label))
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        pending = {pool.submit(run_one, *case, args.frames): case[1].stem
                   for case in tasks}
        for future in as_completed(pending):
            name = pending[future]
            try:
                future.result()
            except Exception as exc:
                print('RBC RVM FAIL:', name, str(exc), file=sys.stderr, flush=True)
                failures.append(name)
''')
print('RVM portfolio concurrency ready')
