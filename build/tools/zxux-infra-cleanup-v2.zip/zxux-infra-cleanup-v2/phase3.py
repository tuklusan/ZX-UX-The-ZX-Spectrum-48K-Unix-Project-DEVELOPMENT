#!/usr/bin/env python3
"""Check generated release structure and clickable source/binary/gallery links."""
from __future__ import annotations
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote
import sys

R = Path.cwd()
D = R / 'dist'
A = D / 'assets'
G = D / 'screenshots'
CATEGORIES = ('c48-bin', 'rbc-bin', 'forth-bin', 'pascal-bin',
              'fortran-bin', 'rb2ct-bin')


def check(ok, message):
    if not ok:
        raise RuntimeError(message)


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.hrefs = []
        self.images = []
        self.in_caption = False
        self.caption_links = 0
        self.captions = []

    def handle_starttag(self, tag, attrs):
        v = dict(attrs)
        if tag == 'figcaption':
            self.in_caption = True
            self.caption_links = 0
        if tag == 'a':
            if 'href' in v:
                self.hrefs.append(v['href'])
                if self.in_caption:
                    self.caption_links += 1
        if tag == 'img' and 'src' in v:
            self.images.append(v['src'])

    def handle_endtag(self, tag):
        if tag == 'figcaption':
            self.in_caption = False
            self.captions.append(self.caption_links)


def main():
    check(D.is_dir(), 'No rebuilt dist/')
    check(not (D / 'bonus').exists(), 'Old dist/bonus still present')
    check(not (G / 'basic-original').exists(), 'Historical BASIC screenshot folder still present')
    check(not (A / 'basic-src' / 'original-sinclair-basic-collections').exists(),
          'Unfiltered BASIC archive in dist/assets')
    expected = set(CATEGORIES)
    got = {p.name for p in A.iterdir() if p.is_dir() and p.name.endswith('-bin')}
    check(got == expected, f'Unexpected bin categories: {got ^ expected}')
    top = {p.name for p in G.iterdir() if p.is_dir()}
    check(top == expected, f'Screenshot categories != bin categories: {top ^ expected}')
    for category in CATEGORIES:
        check((A / category).is_dir(), 'No ' + category)
    for name in ('rbc-src', 'rb2ct', 'rb2ct-src', 'basic-src'):
        check((A / name).is_dir(), 'Missing source folder ' + name)
    check((A / 'basic-src/README.txt').is_file(), 'Missing original BASIC one-line README')
    check(len((A / 'basic-src/README.txt').read_text().splitlines()) == 1,
          'BASIC README must be exactly one line')
    for name in ('assets/forth-bin/results.tsv', 'assets/fortran-bin/samples/results.tsv',
                 'assets/pascal-bin/samples/results.tsv'):
        check(not (D / name).exists(), 'Unwanted release TSV: ' + name)
    check((R / 'src/zx-ux-sdk/rb2ct/c48lib/c48lib.asm').is_file(), 'Missing moved c48lib')
    check(not (R / 'src/zx-ux-sdk/rb2ct/ports').exists(), 'Old rb2ct/ports still exists')
    check((R / 'src/zx-ux-sdk/lib/c48lib.ssa').is_file(), 'Missing source SDK c48lib archive')
    check((D / 'sdk/bin/py/lib/c48lib.ssa').is_file(), 'Missing packaged c48lib archive')
    check(not (R / 'src/assets/forth-src/portable').exists(), 'Old Forth portable folder')
    check(not (R / 'src/assets/forth-src/ported').exists(), 'Old Forth ported folder')
    assert all((A / 'forth-src/examples' / (name + '.fth')).is_file()
               for name in ('calendar', 'pfbench', 'pfsieve', 'hufdemo', 'worms'))
    alias = {'fibarray', 'fibopt', 'fiblarge', 'machar'}
    pas = {p.stem for p in (A / 'pascal-bin/samples/ssx').glob('*.ssx')}
    check(len(pas) == 25 and alias <= pas, 'Pascal release name count/aliases wrong')
    check(not any(n.startswith(('f77s_', 'recovered_')) for n in pas),
          'Historical Pascal names still in release')
    check(len(list((A / 'fortran-bin/samples/ssx').glob('*.ssx'))) == 42,
          'FORTRAN release unexpectedly changed')
    accepted = {(s.parent.parent.name, s.stem) for s in (A / 'rbc-bin').rglob('*.ssx')}
    for source_dir, extension in (('basic-src', '.bas'), ('rbc-src', '.bas')):
        actual = {(s.relative_to(A / source_dir).parts[0], s.parent.name)
                  for s in (A / source_dir).rglob('*' + extension)}
        check(actual == accepted,
              f'{source_dir} must contain only accepted RBC programs: missing={len(accepted - actual)} extra={len(actual - accepted)}')
    for collection, program in accepted:
        originals = A / 'basic-src' / collection / program
        check(any(p.is_file() and p.suffix.lower() == '.tzx' for p in originals.iterdir()),
              'Missing native Spectrum BASIC TZX for ' + program)

    figures = 0
    for category in CATEGORIES:
        if category == 'rb2ct-bin':
            check(not list((G / category).rglob('*.png')), 'rb2ct placeholder has screenshots')
            continue
        base = G / category
        rvm = {p.relative_to(base / 'rvm') for p in (base / 'rvm').rglob('*.png')}
        fuse = {p.relative_to(base / 'fuse') for p in (base / 'fuse').rglob('*.png')}
        check(rvm == fuse, f'Unpaired RVM/Fuse images: {category} '
              f'rvm_only={len(rvm-fuse)} fuse_only={len(fuse-rvm)}')
        for engine in ('rvm', 'fuse'):
            gallery = base / engine
            index = gallery / 'index.html'
            check(index.is_file(), 'Missing gallery: ' + str(index))
            parser = Links()
            parser.feed(index.read_text(encoding='utf-8'))
            check(len(parser.images) == len(rvm), f'Image count wrong: {index}')
            check(all(c >= 2 for c in parser.captions), f'Missing binary/source links: {index}')
            for url in parser.hrefs + parser.images:
                dest = (gallery / unquote(url)).resolve()
                check(dest.is_relative_to(D.resolve()) and dest.is_file(),
                      f'Broken or unsafe link in {index}: {url}')
            figures += len(parser.images)
    # A valid clean-room rebuild may produce different screenshot pixels;
    # this check concerns file/path/source/bin/engine parity, not frame identity.
    print(f'PHASE 3 PASS: all binary/source links resolve; {figures} RVM/Fuse images paired')
    print('No push performed. Review changes, then commit both src/build and dist together.')

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, AssertionError) as exc:
        print('PHASE 3 FAIL:', exc, file=sys.stderr)
        sys.exit(1)
