#!/usr/bin/env bash
# Three-phase one-shot workflow; run from a CLEAN ZX-UX main checkout.
set -euo pipefail
WORKFLOW_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${ZXUX_ROOT:-$PWD}"
cd "$ROOT"
test -f build/build.py && test -d .git || { echo 'Not the ZX-UX repo root' >&2; exit 1; }
if test "${1:-}" = 1 && test -n "$(git status --porcelain)"; then
  echo 'Requires clean checkout (refuses to overwrite unrelated local changes)' >&2
  exit 1
fi
case "${1:-all}" in
  all) for phase in 1 2 3; do bash "$WORKFLOW_DIR/run.sh" "$phase"; done ;;
  1) python3 -B "$WORKFLOW_DIR/phase1.py" ;;
  2)
    fuse_args=(--fuse "${ZXUX_FUSE:-/usr/bin/fuse-sdl}"
               --assets "${ZXUX_FUSE_ASSETS:-/usr/share/fuse}" --jobs 12)
    if test -n "${ZXUX_FUSE_LIBDIR:-}"; then
      fuse_args+=(--libdir "$ZXUX_FUSE_LIBDIR")
    fi
    python3 -B build/build.py "${ZXUX_SJASM:-/usr/local/bin/sjasmplus}"
    python3 -B build/tools/portfolio.py --jobs 12
    python3 -B build/tools/basic_portfolio.py --jobs 12
    python3 -B build/tools/compiler_portfolio.py --engine rvm --jobs 12
    python3 -B build/tools/fuse_portfolio.py "${fuse_args[@]}"
    python3 -B build/tools/basic_fuse_portfolio.py "${fuse_args[@]}"
    python3 -B build/tools/compiler_portfolio.py --engine fuse "${fuse_args[@]}"
    python3 -B build/tools/gallery_index.py
    ;;
  3) python3 -B "$WORKFLOW_DIR/phase3.py" ;;
  *) echo 'Usage: bash run.sh [all|1|2|3]' >&2; exit 2 ;;
esac
